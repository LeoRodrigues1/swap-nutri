package com.mycompany.swapnutri.dao;

import com.mycompany.swapnutri.models.Administrador;
import com.mycompany.swapnutri.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AdministradorDAO {

    private final DatabaseConnection databaseConnection;

    public AdministradorDAO(Connection connection) {
        this.databaseConnection = new DatabaseConnection();
    }

    public void adicionarAdministrador(Administrador administrador) throws SQLException {
        String sql = "INSERT INTO administradores (nome, email, senha) VALUES (?, ?, ?)";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, administrador.getNome());
            pstmt.setString(2, administrador.getEmail());
            pstmt.setString(3, administrador.getSenha());
            pstmt.executeUpdate();
        }
    }

    public Administrador buscarAdministradorPorId(int id) throws SQLException {
        String sql = "SELECT * FROM administradores WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Administrador(
                            rs.getInt("id"),
                            rs.getString("nome"),
                            rs.getString("email"),
                            rs.getString("senha")
                    );
                }
            }
        }
        return null;
    }

    public List<Administrador> listarAdministradores() throws SQLException {
        List<Administrador> administradores = new ArrayList<>();
        String sql = "SELECT * FROM administradores";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Administrador administrador = new Administrador(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("email"),
                        rs.getString("senha")
                );
                administradores.add(administrador);
            }
        }
        return administradores;
    }

    public void atualizarAdministrador(Administrador administrador) throws SQLException {
        String sql = "UPDATE administradores SET nome = ?, email = ?, senha = ? WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, administrador.getNome());
            pstmt.setString(2, administrador.getEmail());
            pstmt.setString(3, administrador.getSenha());
            pstmt.setInt(4, administrador.getId());
            pstmt.executeUpdate();
        }
    }

    public void deletarAdministrador(int id) throws SQLException {
        String sql = "DELETE FROM administradores WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }
}
