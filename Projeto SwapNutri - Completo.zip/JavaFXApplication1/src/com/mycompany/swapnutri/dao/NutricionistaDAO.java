package com.mycompany.swapnutri.dao;

import com.mycompany.swapnutri.models.Nutricionista;
import com.mycompany.swapnutri.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NutricionistaDAO {

    private final DatabaseConnection databaseConnection;

    public NutricionistaDAO(Connection connection) {
        this.databaseConnection = new DatabaseConnection();
    }

    public void adicionarNutricionista(Nutricionista nutricionista) throws SQLException {
        String sql = "INSERT INTO nutricionistas (nome, email, senha) VALUES (?, ?, ?)";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nutricionista.getNome());
            pstmt.setString(2, nutricionista.getEmail());
            pstmt.setString(3, nutricionista.getSenha());
            pstmt.executeUpdate();
        }
    }

    public Nutricionista buscarNutricionistaPorId(int id) throws SQLException {
        String sql = "SELECT * FROM nutricionistas WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Nutricionista(
                            rs.getInt("id"),
                            rs.getString("nome"),
                            rs.getString("email"),
                            rs.getString("senha")
                    );
                }
            }
        }
        return null;
    }

    public List<Nutricionista> listarNutricionistas() throws SQLException {
        List<Nutricionista> nutricionistas = new ArrayList<>();
        String sql = "SELECT * FROM nutricionistas";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Nutricionista nutricionista = new Nutricionista(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("email"),
                        rs.getString("senha")
                );
                nutricionistas.add(nutricionista);
            }
        }
        return nutricionistas;
    }

    public void atualizarNutricionista(Nutricionista nutricionista) throws SQLException {
        String sql = "UPDATE nutricionistas SET nome = ?, email = ?, senha = ? WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, nutricionista.getNome());
            pstmt.setString(2, nutricionista.getEmail());
            pstmt.setString(3, nutricionista.getSenha());
            pstmt.setInt(4, nutricionista.getId());
            pstmt.executeUpdate();
        }
    }

    public void deletarNutricionista(int id) throws SQLException {
        String sql = "DELETE FROM nutricionistas WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }
}

