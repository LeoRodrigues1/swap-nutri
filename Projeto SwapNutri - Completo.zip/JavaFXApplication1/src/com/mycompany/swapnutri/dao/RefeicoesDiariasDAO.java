package com.mycompany.swapnutri.dao;

import com.mycompany.swapnutri.models.RefeicoesDiarias;
import com.mycompany.swapnutri.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class RefeicoesDiariasDAO {

    private final DatabaseConnection databaseConnection;

    public RefeicoesDiariasDAO(Connection connection) {
        this.databaseConnection = new DatabaseConnection();
    }

    public void adicionarRefeicoesDiarias(RefeicoesDiarias refeicoesDiarias) throws SQLException {
        String sql = "INSERT INTO refeicoes_diarias (usuario_id, refeicao, hora_inicio, hora_fim) VALUES (?, ?, ?, ?)";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, refeicoesDiarias.getUsuarioId());
            pstmt.setString(2, refeicoesDiarias.getRefeicao());
            pstmt.setTime(3, refeicoesDiarias.getHoraInicio());
            pstmt.setTime(4, refeicoesDiarias.getHoraFim());
            pstmt.executeUpdate();
        }
    }

    public RefeicoesDiarias buscarRefeicoesDiariasPorId(int id) throws SQLException {
        String sql = "SELECT * FROM refeicoes_diarias WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new RefeicoesDiarias(
                            rs.getInt("id"),
                            rs.getInt("usuario_id"),
                            rs.getString("refeicao"),
                            rs.getTime("hora_inicio"),
                            rs.getTime("hora_fim")
                    );
                }
            }
        }
        return null;
    }

    public List<RefeicoesDiarias> listarRefeicoesDiarias() throws SQLException {
        List<RefeicoesDiarias> refeicoesDiariasList = new ArrayList<>();
        String sql = "SELECT * FROM refeicoes_diarias";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                RefeicoesDiarias refeicoesDiarias = new RefeicoesDiarias(
                        rs.getInt("id"),
                        rs.getInt("usuario_id"),
                        rs.getString("refeicao"),
                        rs.getTime("hora_inicio"),
                        rs.getTime("hora_fim")
                );
                refeicoesDiariasList.add(refeicoesDiarias);
            }
        }
        return refeicoesDiariasList;
    }

    public void atualizarRefeicoesDiarias(RefeicoesDiarias refeicoesDiarias) throws SQLException {
        String sql = "UPDATE refeicoes_diarias SET usuario_id = ?, refeicao = ?, hora_inicio = ?, hora_fim = ? WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, refeicoesDiarias.getUsuarioId());
            pstmt.setString(2, refeicoesDiarias.getRefeicao());
            pstmt.setTime(3, refeicoesDiarias.getHoraInicio());
            pstmt.setTime(4, refeicoesDiarias.getHoraFim());
            pstmt.setInt(5, refeicoesDiarias.getId());
            pstmt.executeUpdate();
        }
    }

    public void deletarRefeicoesDiarias(int id) throws SQLException {
        String sql = "DELETE FROM refeicoes_diarias WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }
}
