package com.mycompany.swapnutri.dao;

import com.mycompany.swapnutri.models.PlanoNutricional;
import com.mycompany.swapnutri.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PlanoNutricionalDAO {

    private final DatabaseConnection databaseConnection;

    public PlanoNutricionalDAO(Connection connection) {
        this.databaseConnection = new DatabaseConnection();
    }

    public void adicionarPlanoNutricional(PlanoNutricional planoNutricional) throws SQLException {
        String sql = "INSERT INTO planos_nutricionais (usuario_id, data_calendario, calorias_meta, carboidratos_meta, proteinas_meta, gorduras_meta, quantidade_agua) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, planoNutricional.getUsuarioId());
            pstmt.setDate(2, new java.sql.Date(planoNutricional.getDataCalendario().getTime()));
            pstmt.setDouble(3, planoNutricional.getCaloriasMeta());
            pstmt.setDouble(4, planoNutricional.getCarboidratosMeta());
            pstmt.setDouble(5, planoNutricional.getProteinasMeta());
            pstmt.setDouble(6, planoNutricional.getGordurasMeta());
            pstmt.setDouble(7, planoNutricional.getQuantidadeAgua());
            pstmt.executeUpdate();
        }
    }

    public PlanoNutricional buscarPlanoNutricionalPorId(int id) throws SQLException {
        String sql = "SELECT * FROM planos_nutricionais WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new PlanoNutricional(
                            rs.getInt("id"),
                            rs.getInt("usuario_id"),
                            rs.getDate("data_calendario"),
                            rs.getDouble("calorias_meta"),
                            rs.getDouble("carboidratos_meta"),
                            rs.getDouble("proteinas_meta"),
                            rs.getDouble("gorduras_meta"),
                            rs.getDouble("quantidade_agua")
                    );
                }
            }
        }
        return null;
    }

    public List<PlanoNutricional> listarPlanosNutricionais() throws SQLException {
        List<PlanoNutricional> planosNutricionais = new ArrayList<>();
        String sql = "SELECT * FROM planos_nutricionais";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                PlanoNutricional planoNutricional = new PlanoNutricional(
                        rs.getInt("id"),
                        rs.getInt("usuario_id"),
                        rs.getDate("data_calendario"),
                        rs.getDouble("calorias_meta"),
                        rs.getDouble("carboidratos_meta"),
                        rs.getDouble("proteinas_meta"),
                        rs.getDouble("gorduras_meta"),
                        rs.getDouble("quantidade_agua")
                );
                planosNutricionais.add(planoNutricional);
            }
        }
        return planosNutricionais;
    }

    public void atualizarPlanoNutricional(PlanoNutricional planoNutricional) throws SQLException {
        String sql = "UPDATE planos_nutricionais SET usuario_id = ?, data_calendario = ?, calorias_meta = ?, carboidratos_meta = ?, proteinas_meta = ?, gorduras_meta = ?, quantidade_agua = ? WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, planoNutricional.getUsuarioId());
            pstmt.setDate(2, new java.sql.Date(planoNutricional.getDataCalendario().getTime()));
            pstmt.setDouble(3, planoNutricional.getCaloriasMeta());
            pstmt.setDouble(4, planoNutricional.getCarboidratosMeta());
            pstmt.setDouble(5, planoNutricional.getProteinasMeta());
            pstmt.setDouble(6, planoNutricional.getGordurasMeta());
            pstmt.setDouble(7, planoNutricional.getQuantidadeAgua());
            pstmt.setInt(8, planoNutricional.getId());
            pstmt.executeUpdate();
        }
    }

    public void deletarPlanoNutricional(int id) throws SQLException {
        String sql = "DELETE FROM planos_nutricionais WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }
}
