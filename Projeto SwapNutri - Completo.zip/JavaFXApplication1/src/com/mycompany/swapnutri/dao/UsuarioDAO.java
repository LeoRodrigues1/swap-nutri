package com.mycompany.swapnutri.dao;

import com.mycompany.swapnutri.models.Usuario;
import com.mycompany.swapnutri.models.Sexo;
import com.mycompany.swapnutri.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    private final DatabaseConnection databaseConnection;

    public UsuarioDAO(Connection connection) {
        this.databaseConnection = new DatabaseConnection();
    }

    public void adicionarUsuario(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO usuarios (nome, email, senha, peso, altura, idade, sexo) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = databaseConnection.obterConexao();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, usuario.getNome());
            pstmt.setString(2, usuario.getEmail());
            pstmt.setString(3, usuario.getSenha());
            pstmt.setFloat(4, usuario.getPeso());
            pstmt.setFloat(5, usuario.getAltura());
            pstmt.setInt(6, usuario.getIdade());
            pstmt.setString(7, usuario.getSexo().name());
            pstmt.executeUpdate();
        }
    }

    public Usuario buscarUsuarioPorId(int id) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(
                            rs.getInt("id"),
                            rs.getString("nome"),
                            rs.getString("email"),
                            rs.getString("senha"),
                            rs.getFloat("peso"),
                            rs.getFloat("altura"),
                            rs.getInt("idade"),
                            Sexo.valueOf(rs.getString("sexo"))
                    );
                }
            }
        }
        return null;
    }

    public List<Usuario> listarUsuarios() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Usuario usuario = new Usuario(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("email"),
                        rs.getString("senha"),
                        rs.getFloat("peso"),
                        rs.getFloat("altura"),
                        rs.getInt("idade"),
                        Sexo.valueOf(rs.getString("sexo"))
                );
                usuarios.add(usuario);
            }
        }
        return usuarios;
    }

    public void atualizarUsuario(Usuario usuario) throws SQLException {
        String sql = "UPDATE usuarios SET nome = ?, email = ?, senha = ?, peso = ?, altura = ?, idade = ?, sexo = ? WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, usuario.getNome());
            pstmt.setString(2, usuario.getEmail());
            pstmt.setString(3, usuario.getSenha());
            pstmt.setFloat(4, usuario.getPeso());
            pstmt.setFloat(5, usuario.getAltura());
            pstmt.setInt(6, usuario.getIdade());
            pstmt.setString(7, usuario.getSexo().name());
            pstmt.setInt(8, (int) usuario.getId());
            pstmt.executeUpdate();
        }
    }

    public void deletarUsuario(int id) throws SQLException {
        String sql = "DELETE FROM usuarios WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }
}
