package com.mycompany.swapnutri.dao;

import com.mycompany.swapnutri.models.ItensRefeicao;
import com.mycompany.swapnutri.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItensRefeicaoDAO {

    private final DatabaseConnection databaseConnection;

    public ItensRefeicaoDAO(Connection connection) {
        this.databaseConnection = new DatabaseConnection();
    }

    public void adicionarItensRefeicao(ItensRefeicao itensRefeicao) throws SQLException {
        String sql = "INSERT INTO itens_refeicao (refeicoes_diarias_id, alimento_id, quantidade) VALUES (?, ?, ?)";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, itensRefeicao.getRefeicoesDiariasId());
            pstmt.setInt(2, itensRefeicao.getAlimentoId());
            pstmt.setDouble(3, itensRefeicao.getQuantidade());
            pstmt.executeUpdate();
        }
    }

    public ItensRefeicao buscarItensRefeicaoPorId(int id) throws SQLException {
        String sql = "SELECT * FROM itens_refeicao WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new ItensRefeicao(
                            rs.getInt("id"),
                            rs.getInt("refeicoes_diarias_id"),
                            rs.getInt("alimento_id"),
                            rs.getDouble("quantidade")
                    );
                }
            }
        }
        return null;
    }

    public List<ItensRefeicao> listarItensRefeicao() throws SQLException {
        List<ItensRefeicao> itensRefeicaoList = new ArrayList<>();
        String sql = "SELECT * FROM itens_refeicao";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                ItensRefeicao itensRefeicao = new ItensRefeicao(
                        rs.getInt("id"),
                        rs.getInt("refeicoes_diarias_id"),
                        rs.getInt("alimento_id"),
                        rs.getDouble("quantidade")
                );
                itensRefeicaoList.add(itensRefeicao);
            }
        }
        return itensRefeicaoList;
    }

    public void atualizarItensRefeicao(ItensRefeicao itensRefeicao) throws SQLException {
        String sql = "UPDATE itens_refeicao SET refeicoes_diarias_id = ?, alimento_id = ?, quantidade = ? WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, itensRefeicao.getRefeicoesDiariasId());
            pstmt.setInt(2, itensRefeicao.getAlimentoId());
            pstmt.setDouble(3, itensRefeicao.getQuantidade());
            pstmt.setInt(4, itensRefeicao.getId());
            pstmt.executeUpdate();
        }
    }

    public void deletarItensRefeicao(int id) throws SQLException {
        String sql = "DELETE FROM itens_refeicao WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }
}
