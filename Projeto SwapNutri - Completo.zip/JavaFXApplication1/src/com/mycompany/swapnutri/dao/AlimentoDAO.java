package com.mycompany.swapnutri.dao;

import com.mycompany.swapnutri.models.Alimento;
import com.mycompany.swapnutri.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AlimentoDAO {

   private final DatabaseConnection databaseConnection;

    public AlimentoDAO(Connection connection) {
        this.databaseConnection = new DatabaseConnection();
    }
    public void adicionarAlimento(Alimento alimento) throws SQLException {
        String sql = "INSERT INTO alimentos (nome, categoria, calorias, carboidratos, proteinas, gorduras_totais, gorduras_saturadas, fibras, peso_g, volume_ml) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, alimento.getNome());
            pstmt.setString(2, alimento.getCategoria());
            pstmt.setDouble(3, alimento.getCalorias());
            pstmt.setDouble(4, alimento.getCarboidratos());
            pstmt.setDouble(5, alimento.getProteinas());
            pstmt.setDouble(6, alimento.getGorduras_totais());
            pstmt.setDouble(7, alimento.getGorduras_saturadas());
            pstmt.setDouble(8, alimento.getFibras());
            pstmt.setDouble(9, alimento.getPeso_g());
            pstmt.setDouble(10, alimento.getVolume_ml());
            pstmt.executeUpdate();
        }
    }
public List<Alimento> buscarAlimentosPorNome(String nome) throws SQLException {
    List<Alimento> alimentos = new ArrayList<>();
    String sql = "SELECT * FROM alimentos WHERE LOWER(nome) LIKE LOWER(?)";

    try (Connection conn = databaseConnection.obterConexao();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, "%" + nome + "%");
        try (ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                alimentos.add(new Alimento(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("categoria"),
                        rs.getDouble("calorias"),
                        rs.getDouble("carboidratos"),
                        rs.getDouble("proteinas"),
                        rs.getDouble("gorduras_totais"),
                        rs.getDouble("gorduras_saturadas"),
                        rs.getDouble("fibras"),
                        rs.getDouble("peso_g"),
                        rs.getDouble("volume_ml")
                ));
                
            }
            
        }
    }
    return alimentos;
}

    public Alimento buscarAlimentoPorId(int id) throws SQLException {
        String sql = "SELECT * FROM alimentos WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Alimento(
                            rs.getInt("id"),
                            rs.getString("nome"),
                            rs.getString("categoria"),
                            rs.getDouble("calorias"),
                            rs.getDouble("carboidratos"),
                            rs.getDouble("proteinas"),
                            rs.getDouble("gorduras_totais"),
                            rs.getDouble("gorduras_saturadas"),
                            rs.getDouble("fibras"),
                            rs.getDouble("peso_g"),
                            rs.getDouble("volume_ml")
                    );
                }
            }
        }
        return null;
    }

    public List<Alimento> listarAlimentos() throws SQLException {
        List<Alimento> alimentos = new ArrayList<>();
        String sql = "SELECT * FROM alimentos";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Alimento alimento = new Alimento(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("categoria"),
                        rs.getDouble("calorias"),
                        rs.getDouble("carboidratos"),
                        rs.getDouble("proteinas"),
                        rs.getDouble("gorduras_totais"),
                        rs.getDouble("gorduras_saturadas"),
                        rs.getDouble("fibras"),
                        rs.getDouble("peso_g"),
                        rs.getDouble("volume_ml")
                );
                alimentos.add(alimento);
            }
        }
        return alimentos;
    }

    public void atualizarAlimento(Alimento alimento) throws SQLException {
        String sql = "UPDATE alimentos SET nome = ?, categoria = ?, calorias = ?, carboidratos = ?, proteinas = ?, gorduras_totais = ?, gorduras_saturadas = ?, fibra = ?, peso_g = ?, volume_ml = ? WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, alimento.getNome());
            pstmt.setString(2, alimento.getCategoria());
            pstmt.setDouble(3, alimento.getCalorias());
            pstmt.setDouble(4, alimento.getCarboidratos());
            pstmt.setDouble(5, alimento.getProteinas());
            pstmt.setDouble(6, alimento.getGorduras_totais());
            pstmt.setDouble(7, alimento.getGorduras_saturadas());
            pstmt.setDouble(8, alimento.getFibras());
            pstmt.setDouble(9, alimento.getPeso_g());
            pstmt.setDouble(10, alimento.getVolume_ml());
            pstmt.setInt(11, alimento.getId());
            pstmt.executeUpdate();
        }
    }

    public void deletarAlimento(int id) throws SQLException {
        String sql = "DELETE FROM alimentos WHERE id = ?";

        try (Connection conn = databaseConnection.obterConexao();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }
}
