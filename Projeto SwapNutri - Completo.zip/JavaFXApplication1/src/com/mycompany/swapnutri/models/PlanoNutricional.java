package com.mycompany.swapnutri.models;

import java.util.Date;

public class PlanoNutricional {
    private int id;
    private int usuarioId;
    private Date dataCalendario;
    private double caloriasMeta;
    private double carboidratosMeta;
    private double proteinasMeta;
    private double gordurasMeta;
    private double quantidadeAgua;

    public PlanoNutricional(int id, int usuarioId, Date dataCalendario, double caloriasMeta, double carboidratosMeta, double proteinasMeta, double gordurasMeta, double quantidadeAgua) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.dataCalendario = dataCalendario;
        this.caloriasMeta = caloriasMeta;
        this.carboidratosMeta = carboidratosMeta;
        this.proteinasMeta = proteinasMeta;
        this.gordurasMeta = gordurasMeta;
        this.quantidadeAgua = quantidadeAgua;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public Date getDataCalendario() {
        return dataCalendario;
    }

    public void setDataCalendario(Date dataCalendario) {
        this.dataCalendario = dataCalendario;
    }

    public double getCaloriasMeta() {
        return caloriasMeta;
    }

    public void setCaloriasMeta(double caloriasMeta) {
        this.caloriasMeta = caloriasMeta;
    }

    public double getCarboidratosMeta() {
        return carboidratosMeta;
    }

    public void setCarboidratosMeta(double carboidratosMeta) {
        this.carboidratosMeta = carboidratosMeta;
    }

    public double getProteinasMeta() {
        return proteinasMeta;
    }

    public void setProteinasMeta(double proteinasMeta) {
        this.proteinasMeta = proteinasMeta;
    }

    public double getGordurasMeta() {
        return gordurasMeta;
    }

    public void setGordurasMeta(double gordurasMeta) {
        this.gordurasMeta = gordurasMeta;
    }

    public double getQuantidadeAgua() {
        return quantidadeAgua;
    }

    public void setQuantidadeAgua(double quantidadeAgua) {
        this.quantidadeAgua = quantidadeAgua;
    }

    // Método hashCode, equals e toString (opcionais)

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("PlanoNutricional:");
        sb.append("id=").append(id);
        sb.append(", usuarioId=").append(usuarioId);
        sb.append(", dataCalendario=").append(dataCalendario);
        sb.append(", caloriasMeta=").append(caloriasMeta);
        sb.append(", carboidratosMeta=").append(carboidratosMeta);
        sb.append(", proteinasMeta=").append(proteinasMeta);
        sb.append(", gordurasMeta=").append(gordurasMeta);
        sb.append(", quantidadeAgua=").append(quantidadeAgua);
        return sb.toString();
    }
    
}
