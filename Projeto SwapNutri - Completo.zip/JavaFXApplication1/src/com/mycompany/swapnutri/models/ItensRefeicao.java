package com.mycompany.swapnutri.models;

public class ItensRefeicao {
    private int id;
    private int refeicoesDiariasId;
    private int alimentoId;
    private double quantidade;

    public ItensRefeicao(int id, int refeicoesDiariasId, int alimentoId, double quantidade) {
        this.id = id;
        this.refeicoesDiariasId = refeicoesDiariasId;
        this.alimentoId = alimentoId;
        this.quantidade = quantidade;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRefeicoesDiariasId() {
        return refeicoesDiariasId;
    }

    public void setRefeicoesDiariasId(int refeicoesDiariasId) {
        this.refeicoesDiariasId = refeicoesDiariasId;
    }

    public int getAlimentoId() {
        return alimentoId;
    }

    public void setAlimentoId(int alimentoId) {
        this.alimentoId = alimentoId;
    }

    public double getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade;
    }

    // Métodos hashCode, equals e toString (opcionais)

    @Override
    public String toString() {
        return "ItensRefeicao{" +
                "id=" + id +
                ", refeicoesDiariasId=" + refeicoesDiariasId +
                ", alimentoId=" + alimentoId +
                ", quantidade=" + quantidade +
                '}';
    }
}
