package com.mycompany.swapnutri.models;

/**
 * Classe que representa um usuário no sistema Swap Nutri.
 */
public class Usuario {
    private long id;
    private String nome;
    private String email;
    private String senha;
    private float peso;
    private float altura;
    private int idade;
    private Sexo sexo;

    //Construtor da classe Usuario.

    public Usuario(long id, String nome, String email, String senha, float peso, float altura, int idade, Sexo sexo) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.peso = peso;
        this.altura = altura;
        this.idade = idade;
        this.sexo = sexo;
    }

    public Usuario(String nome) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters e Setters

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }

    //  Método hashCode para geração de código hash baseado no ID do usuário.
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + (int) (this.id ^ (this.id >>> 32));
        return hash;
    }

    /**
     * Método equals para comparar se dois objetos Usuario são iguais, baseado no ID.
     * 
     * @param obj Objeto a ser comparado.
     * @return true se os objetos forem iguais, false caso contrário.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        return this.id == other.id;
    }

    /**
     * Método toString para fornecer uma representação legível do objeto Usuario.
     * 
     * @return String que representa o objeto Usuario.
     */
    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", email='" + email + '\'' +
                ", peso=" + peso +
                ", altura=" + altura +
                ", idade=" + idade +
                ", sexo=" + sexo +
                '}';
    }

    /**
     * Método de validação para verificar se o email e a senha estão preenchidos.
     * 
     * @return true se o email e a senha estiverem preenchidos, false caso contrário.
     */
    public boolean isValid() {
        return email != null && !email.isEmpty() && senha != null && !senha.isEmpty();
    }
}
