package com.mycompany.swapnutri.models;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class RefeicoesDiarias {
    private int id;
    private int usuarioId;
    private String refeicao;
    private Time horaInicio;
    private Time horaFim;
    private List<ItensRefeicao> itens;

    public RefeicoesDiarias(int id, int usuarioId, String refeicao, Time horaInicio, Time horaFim) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.refeicao = refeicao;
        this.horaInicio = horaInicio;
        this.horaFim = horaFim;
        this.itens = new ArrayList<>();
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getRefeicao() {
        return refeicao;
    }

    public void setRefeicao(String refeicao) {
        this.refeicao = refeicao;
    }

    public Time getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Time horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Time getHoraFim() {
        return horaFim;
    }

    public void setHoraFim(Time horaFim) {
        this.horaFim = horaFim;
    }

    public List<ItensRefeicao> getItens() {
        return itens;
    }

    public void setItens(List<ItensRefeicao> itens) {
        this.itens = itens;
    }

    // Método para adicionar um item à refeição
    public void adicionarItem(ItensRefeicao item) {
        this.itens.add(item);
    }

    // Método hashCode, equals e toString (opcionais)
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RefeicoesDiarias other = (RefeicoesDiarias) obj;
        return this.id == other.id;
    }

    @Override
    public String toString() {
        return "RefeicoesDiarias{" +
                "id=" + id +
                ", usuarioId=" + usuarioId +
                ", refeicao='" + refeicao + '\'' +
                ", horaInicio=" + horaInicio +
                ", horaFim=" + horaFim +
                ", itens=" + itens +
                '}';
    }

    public void add(RefeicoesDiarias refeicoesDiarias) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
