package com.mycompany.swapnutri.models;

public class Alimento {
    private int id;
    private String nome;
    private String categoria;
    private double calorias;
    private double carboidratos;
    private double proteinas;
    private double gorduras_totais;
    private double gorduras_saturadas;
    private double fibras;
    private double peso_g;
    private double volume_ml;

    // Construtor da classe Alimento
    
    public Alimento(int id, String nome, String categoria, double calorias, double carboidratos, double proteinas, double gorduras_totais, double gorduras_saturadas, double fibras, double peso_g, double volume_ml) {
        this.id = id;
        this.nome = nome;
        this.categoria = categoria;
        this.calorias = calorias;
        this.carboidratos = carboidratos;
        this.proteinas = proteinas;
        this.gorduras_totais = gorduras_totais;
        this.gorduras_saturadas = gorduras_saturadas;
        this.fibras = fibras;
        this.peso_g = peso_g;
        this.volume_ml = volume_ml;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getCalorias() {
        return calorias;
    }

    public void setCalorias(double calorias) {
        this.calorias = calorias;
    }

    public double getCarboidratos() {
        return carboidratos;
    }

    public void setCarboidratos(double carboidratos) {
        this.carboidratos = carboidratos;
    }

    public double getProteinas() {
        return proteinas;
    }

    public void setProteinas(double proteinas) {
        this.proteinas = proteinas;
    }

    public double getGorduras_totais() {
        return gorduras_totais;
    }

    public void setGorduras_totais(double gorduras_totais) {
        this.gorduras_totais = gorduras_totais;
    }

    public double getGorduras_saturadas() {
        return gorduras_saturadas;
    }

    public void setGorduras_saturadas(double gorduras_saturadas) {
        this.gorduras_saturadas = gorduras_saturadas;
    }

    public double getFibras() {
        return fibras;
    }

    public void setFibras(double fibras) {
        this.fibras = fibras;
    }

    public double getPeso_g() {
        return peso_g;
    }

    public void setPeso_g(double peso_g) {
        this.peso_g = peso_g;
    }

    public double getVolume_ml() {
        return volume_ml;
    }

    public void setVolume_ml(double volume_ml) {
        this.volume_ml = volume_ml;
    }

    // Método hashCode
@Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + this.id;
    return hash;
}

    // Método equals
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Alimento other = (Alimento) obj;
        return this.id == other.id;
    }

    // Método toString
    @Override
    public String toString() {
        return "Alimento{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", categoria='" + categoria + '\'' +
                ", calorias=" + calorias +
                ", carboidratos=" + carboidratos +
                ", proteinas=" + proteinas +
                ", gorduras_totais=" + gorduras_totais +
                ", gorduras_saturadas=" + gorduras_saturadas +
                ", fibras=" + fibras +
                ", peso_g=" + peso_g +
                ", volume_ml=" + volume_ml +
                '}';
       
    }
}
