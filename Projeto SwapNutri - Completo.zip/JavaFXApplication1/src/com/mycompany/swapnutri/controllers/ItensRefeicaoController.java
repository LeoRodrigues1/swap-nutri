package com.mycompany.swapnutri.controllers;

import com.mycompany.swapnutri.models.ItensRefeicao;
import com.mycompany.swapnutri.services.ItensRefeicaoService;

import java.sql.Connection;
import java.util.List;

public class ItensRefeicaoController {
    private final ItensRefeicaoService itensRefeicaoService;

    public ItensRefeicaoController(Connection connection) {
        this.itensRefeicaoService = new ItensRefeicaoService(connection);
    }

    public void adicionarItensRefeicao(ItensRefeicao itensRefeicao) {
        try {
            itensRefeicaoService.adicionarItensRefeicao(itensRefeicao);
            System.out.println("Item de refeição adicionado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao adicionar item de refeição: " + e.getMessage());
        }
    }

    public void buscarItensRefeicaoPorId(int id) {
        try {
            ItensRefeicao itensRefeicao = itensRefeicaoService.buscarItensRefeicaoPorId(id);
            if (itensRefeicao != null) {
                System.out.println(itensRefeicao);
            } else {
                System.out.println("Item de refeição não encontrado.");
            }
        } catch (RuntimeException e) {
            System.err.println("Erro ao buscar item de refeição: " + e.getMessage());
        }
    }

    public void listarItensRefeicao() {
        try {
            List<ItensRefeicao> itensRefeicao = itensRefeicaoService.listarItensRefeicao();
            itensRefeicao.forEach(System.out::println);
        } catch (RuntimeException e) {
            System.err.println("Erro ao listar itens de refeição: " + e.getMessage());
        }
    }

    public void atualizarItensRefeicao(ItensRefeicao itensRefeicao) {
        try {
            itensRefeicaoService.atualizarItensRefeicao(itensRefeicao);
            System.out.println("Item de refeição atualizado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao atualizar item de refeição: " + e.getMessage());
        }
    }

    public void deletarItensRefeicao(int id) {
        try {
            itensRefeicaoService.deletarItensRefeicao(id);
            System.out.println("Item de refeição deletado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao deletar item de refeição: " + e.getMessage());
        }
    }
}
