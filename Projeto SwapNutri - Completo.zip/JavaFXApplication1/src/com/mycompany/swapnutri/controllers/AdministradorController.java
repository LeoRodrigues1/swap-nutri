package com.mycompany.swapnutri.controllers;

import com.mycompany.swapnutri.models.Administrador;
import com.mycompany.swapnutri.services.AdministradorService;

import java.sql.Connection;
import java.util.List;

public class AdministradorController {
    private final AdministradorService administradorService;

    public AdministradorController(Connection connection) {
        this.administradorService = new AdministradorService(connection);
    }

    public void adicionarAdministrador(Administrador administrador) {
        try {
            administradorService.adicionarAdministrador(administrador);
            System.out.println("Administrador adicionado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao adicionar administrador: " + e.getMessage());
        }
    }

    public void buscarAdministradorPorId(int id) {
        try {
            Administrador administrador = administradorService.buscarAdministradorPorId(id);
            if (administrador != null) {
                System.out.println(administrador);
            } else {
                System.out.println("Administrador não encontrado.");
            }
        } catch (RuntimeException e) {
            System.err.println("Erro ao buscar administrador: " + e.getMessage());
        }
    }

    public void listarAdministradores() {
        try {
            List<Administrador> administradores = administradorService.listarAdministradores();
            administradores.forEach(System.out::println);
        } catch (RuntimeException e) {
            System.err.println("Erro ao listar administradores: " + e.getMessage());
        }
    }

    public void atualizarAdministrador(Administrador administrador) {
        try {
            administradorService.atualizarAdministrador(administrador);
            System.out.println("Administrador atualizado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao atualizar administrador: " + e.getMessage());
        }
    }

    public void deletarAdministrador(int id) {
        try {
            administradorService.deletarAdministrador(id);
            System.out.println("Administrador deletado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao deletar administrador: " + e.getMessage());
        }
    }
}
