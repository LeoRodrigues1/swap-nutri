package com.mycompany.swapnutri.controllers;

import com.mycompany.swapnutri.models.RefeicoesDiarias;
import com.mycompany.swapnutri.services.RefeicoesDiariasService;

import java.sql.Connection;
import java.util.List;

public class RefeicoesDiariasController {
    private final RefeicoesDiariasService refeicoesDiariasService;

    public RefeicoesDiariasController(Connection connection) {
        this.refeicoesDiariasService = new RefeicoesDiariasService(connection);
    }

    public void adicionarRefeicoesDiarias(RefeicoesDiarias refeicoesDiarias) {
        try {
            refeicoesDiariasService.adicionarRefeicoesDiarias(refeicoesDiarias);
            System.out.println("Refeição diária adicionada com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao adicionar refeição diária: " + e.getMessage());
        }
    }

    public void buscarRefeicoesDiariasPorId(int id) {
        try {
            RefeicoesDiarias refeicoesDiarias = refeicoesDiariasService.buscarRefeicoesDiariasPorId(id);
            if (refeicoesDiarias != null) {
                System.out.println(refeicoesDiarias);
            } else {
                System.out.println("Refeição diária não encontrada.");
            }
        } catch (RuntimeException e) {
            System.err.println("Erro ao buscar refeição diária: " + e.getMessage());
        }
    }

    public void listarRefeicoesDiarias() {
        try {
            List<RefeicoesDiarias> refeicoesDiarias = refeicoesDiariasService.listarRefeicoesDiarias();
            refeicoesDiarias.forEach(System.out::println);
        } catch (RuntimeException e) {
            System.err.println("Erro ao listar refeições diárias: " + e.getMessage());
        }
    }

    public void atualizarRefeicoesDiarias(RefeicoesDiarias refeicoesDiarias) {
        try {
            refeicoesDiariasService.atualizarRefeicoesDiarias(refeicoesDiarias);
            System.out.println("Refeição diária atualizada com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao atualizar refeição diária: " + e.getMessage());
        }
    }

    public void deletarRefeicoesDiarias(int id) {
        try {
            refeicoesDiariasService.deletarRefeicoesDiarias(id);
            System.out.println("Refeição diária deletada com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao deletar refeição diária: " + e.getMessage());
        }
    }
}
