package com.mycompany.swapnutri.controllers;

import com.mycompany.swapnutri.models.PlanoNutricional;
import com.mycompany.swapnutri.services.PlanoNutricionalService;

import java.sql.Connection;
import java.util.List;

public class PlanoNutricionalController {
    private final PlanoNutricionalService planoNutricionalService;

    public PlanoNutricionalController(Connection connection) {
        this.planoNutricionalService = new PlanoNutricionalService(connection);
    }

    public void adicionarPlanoNutricional(PlanoNutricional planoNutricional) {
        try {
            planoNutricionalService.adicionarPlanoNutricional(planoNutricional);
            System.out.println("Plano Nutricional adicionado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao adicionar plano nutricional: " + e.getMessage());
        }
    }

    public void buscarPlanoNutricionalPorId(int id) {
        try {
            PlanoNutricional planoNutricional = planoNutricionalService.buscarPlanoNutricionalPorId(id);
            if (planoNutricional != null) {
                System.out.println(planoNutricional);
            } else {
                System.out.println("Plano Nutricional não encontrado.");
            }
        } catch (RuntimeException e) {
            System.err.println("Erro ao buscar plano nutricional: " + e.getMessage());
        }
    }

    public void listarPlanosNutricionais() {
        try {
            List<PlanoNutricional> planosNutricionais = planoNutricionalService.listarPlanosNutricionais();
            planosNutricionais.forEach(System.out::println);
        } catch (RuntimeException e) {
            System.err.println("Erro ao listar planos nutricionais: " + e.getMessage());
        }
    }

    public void atualizarPlanoNutricional(PlanoNutricional planoNutricional) {
        try {
            planoNutricionalService.atualizarPlanoNutricional(planoNutricional);
            System.out.println("Plano Nutricional atualizado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao atualizar plano nutricional: " + e.getMessage());
        }
    }

    public void deletarPlanoNutricional(int id) {
        try {
            planoNutricionalService.deletarPlanoNutricional(id);
            System.out.println("Plano Nutricional deletado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao deletar plano nutricional: " + e.getMessage());
        }
    }
}
