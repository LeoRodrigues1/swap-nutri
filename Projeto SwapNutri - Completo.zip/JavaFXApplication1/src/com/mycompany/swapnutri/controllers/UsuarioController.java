package com.mycompany.swapnutri.controllers;

import com.mycompany.swapnutri.models.Usuario;
import com.mycompany.swapnutri.services.UsuarioService;
import com.mycompany.swapnutri.utils.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class UsuarioController {
    private final Connection connection;
    private final UsuarioService usuarioService;

    // Constructor
    public UsuarioController(Connection connection) {
        this.connection = connection;
        this.usuarioService = new UsuarioService(connection);
    }

    // Method to add a new user
    public boolean adicionarUsuario(Usuario usuario) {
        try {
            usuarioService.adicionarUsuario(usuario);
            return true;
        } catch (RuntimeException e) {
            System.err.println("Erro ao adicionar usuário: " + e.getMessage());
            return false;
        }
    }

    // Method to find user by ID
    public Usuario buscarUsuarioPorId(int id) {
        try {
            return usuarioService.buscarUsuarioPorId(id);
        } catch (RuntimeException e) {
            System.err.println("Erro ao buscar usuário: " + e.getMessage());
            return null;
        }
    }

    // Method to list all users
    public List<Usuario> listarUsuarios() {
        try {
            return usuarioService.listarUsuarios();
        } catch (RuntimeException e) {
            System.err.println("Erro ao listar usuários: " + e.getMessage());
            return null;
        }
    }

    // Method to update user
    public boolean atualizarUsuario(Usuario usuario) {
        try {
            usuarioService.atualizarUsuario(usuario);
            return true;
        } catch (RuntimeException e) {
            System.err.println("Erro ao atualizar usuário: " + e.getMessage());
            return false;
        }
    }

    // Method to delete user by ID
    public boolean deletarUsuario(int id) {
        try {
            usuarioService.deletarUsuario(id);
            return true;
        } catch (RuntimeException e) {
            System.err.println("Erro ao deletar usuário: " + e.getMessage());
            return false;
        }
    }

    // Login method with credentials verification
public boolean verificarCredenciais(String email, String senha) {
    String query = "SELECT * FROM usuarios WHERE email = ? AND senha = ?"; // Nome corrigido
    
    try (PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, email);
        stmt.setString(2, senha);
        
        try (ResultSet rs = stmt.executeQuery()) {
            return rs.next();
        }
    } catch (SQLException e) {
        System.err.println("Erro ao verificar credenciais: " + e.getMessage());
        return false;
    }
}

    // Optional method to get database connection
    public static Connection obterConexao() {
        return DatabaseConnection.getConnection();
    }
}