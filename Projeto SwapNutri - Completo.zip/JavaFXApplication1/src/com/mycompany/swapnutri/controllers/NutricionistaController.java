package com.mycompany.swapnutri.controllers;

import com.mycompany.swapnutri.models.Nutricionista;
import com.mycompany.swapnutri.services.NutricionistaService;

import java.sql.Connection;
import java.util.List;

public class NutricionistaController {
    private final NutricionistaService nutricionistaService;

    public NutricionistaController(Connection connection) {
        this.nutricionistaService = new NutricionistaService(connection);
    }

    public void adicionarNutricionista(Nutricionista nutricionista) {
        try {
            nutricionistaService.adicionarNutricionista(nutricionista);
            System.out.println("Nutricionista adicionado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao adicionar nutricionista: " + e.getMessage());
        }
    }

    public void buscarNutricionistaPorId(int id) {
        try {
            Nutricionista nutricionista = nutricionistaService.buscarNutricionistaPorId(id);
            if (nutricionista != null) {
                System.out.println(nutricionista);
            } else {
                System.out.println("Nutricionista não encontrado.");
            }
        } catch (RuntimeException e) {
            System.err.println("Erro ao buscar nutricionista: " + e.getMessage());
        }
    }

    public void listarNutricionistas() {
        try {
            List<Nutricionista> nutricionistas = nutricionistaService.listarNutricionistas();
            nutricionistas.forEach(System.out::println);
        } catch (RuntimeException e) {
            System.err.println("Erro ao listar nutricionistas: " + e.getMessage());
        }
    }

    public void atualizarNutricionista(Nutricionista nutricionista) {
        try {
            nutricionistaService.atualizarNutricionista(nutricionista);
            System.out.println("Nutricionista atualizado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao atualizar nutricionista: " + e.getMessage());
        }
    }

    public void deletarNutricionista(int id) {
        try {
            nutricionistaService.deletarNutricionista(id);
            System.out.println("Nutricionista deletado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao deletar nutricionista: " + e.getMessage());
        }
    }
}
