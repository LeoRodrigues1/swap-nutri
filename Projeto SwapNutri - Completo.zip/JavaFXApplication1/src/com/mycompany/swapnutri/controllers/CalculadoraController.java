package com.mycompany.swapnutri.controllers;

import com.mycompany.swapnutri.dao.AlimentoDAO;
import com.mycompany.swapnutri.models.Alimento;
import com.mycompany.swapnutri.services.CalculadoraService;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class CalculadoraController {
    private final CalculadoraService calcService;
    private final AlimentoDAO alimentoDAO;

    public CalculadoraController(Connection connection) {
        this.calcService = new CalculadoraService(connection);
        this.alimentoDAO = new AlimentoDAO(connection);
    }

    // Método para calcular a substituição de calorias
    public String calcularSubstituicao(String nomeAlimentoOriginal, double quantidade, String nomeAlimentoSubstituto) {
        try {
            // Buscar alimentos pelo nome
            List<Alimento> alimentosOriginal = alimentoDAO.buscarAlimentosPorNome(nomeAlimentoOriginal);
            List<Alimento> alimentosSubstituto = alimentoDAO.buscarAlimentosPorNome(nomeAlimentoSubstituto);

            // Verificar se algum dos alimentos foi encontrado
            if (alimentosOriginal.isEmpty() || alimentosSubstituto.isEmpty()) {
                return "Um ou ambos os alimentos não foram encontrados.";
            }

            // Obter os primeiros alimentos da lista (caso haja múltiplos resultados)
            Alimento alimentoOriginal = alimentosOriginal.get(0);
            Alimento alimentoSubstituto = alimentosSubstituto.get(0);

            // Calcular a substituição com base nas calorias
            double resultado = calcService.calcularEquivalencia(alimentoOriginal, quantidade, alimentoSubstituto);

            // Retornar o resultado formatado
            return String.format("A quantidade equivalente de %s para substituir %s é: %.2f", 
                                 alimentoSubstituto.getNome(), alimentoOriginal.getNome(), resultado);
        } catch (SQLException e) {
            return "Erro ao buscar alimentos ou calcular a substituição: " + e.getMessage();
        }
    }

    // Método para calcular a substituição por nutriente
    public String calcularSubstituicaoNutriente(String nutriente, String nomeAlimentoOriginal, double quantidade, String nomeAlimentoSubstituto) {
        try {
            // Buscar alimentos pelo nome
            List<Alimento> alimentosOriginal = alimentoDAO.buscarAlimentosPorNome(nomeAlimentoOriginal);
            List<Alimento> alimentosSubstituto = alimentoDAO.buscarAlimentosPorNome(nomeAlimentoSubstituto);

            // Verificar se algum dos alimentos foi encontrado
            if (alimentosOriginal.isEmpty() || alimentosSubstituto.isEmpty()) {
                return "Um ou ambos os alimentos não foram encontrados.";
            }

            // Obter os primeiros alimentos da lista (caso haja múltiplos resultados)
            Alimento alimentoOriginal = alimentosOriginal.get(0);
            Alimento alimentoSubstituto = alimentosSubstituto.get(0);

            // Calcular a substituição com base no nutriente escolhido
            double resultado = calcService.calcularPorNutriente(nutriente, alimentoOriginal, quantidade, alimentoSubstituto);

            // Retornar o resultado formatado
            return String.format("A quantidade equivalente de %s (%s) para substituir %s é: %.2f", 
                                 nutriente, alimentoSubstituto.getNome(), alimentoOriginal.getNome(), resultado);
        } catch (SQLException e) {
            return "Erro ao buscar alimentos ou calcular a substituição: " + e.getMessage();
        }
    }
}
