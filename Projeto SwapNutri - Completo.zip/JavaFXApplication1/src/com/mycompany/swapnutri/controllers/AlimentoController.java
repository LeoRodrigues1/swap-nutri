package com.mycompany.swapnutri.controllers;

import com.mycompany.swapnutri.models.Alimento;
import com.mycompany.swapnutri.services.AlimentoService;
import java.sql.Connection;
import java.util.List;

public class AlimentoController {
    private final AlimentoService alimentoService;

    public AlimentoController(Connection connection) {
        this.alimentoService = new AlimentoService(connection);
    }

    public void adicionarAlimento(Alimento alimento) {
        try {
            alimentoService.adicionarAlimento(alimento);
            System.out.println("Alimento adicionado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao adicionar alimento: " + e.getMessage());
        }
    }
public void buscarAlimentosPorNome(String nome) {
    try {
        List<Alimento> alimentos = alimentoService.buscarAlimentosPorNome(nome);
        if (alimentos.isEmpty()) {
            System.out.println("Nenhum alimento encontrado.");
        } else {
            alimentos.forEach(System.out::println);
        }
    } catch (RuntimeException e) {
        System.err.println("Erro ao buscar alimentos por nome: " + e.getMessage());
    }
}

    public void buscarAlimentoPorId(int id) {
        try {
            Alimento alimento = alimentoService.buscarAlimentoPorId(id);
            if (alimento != null) {
                System.out.println(alimento);
            } else {
                System.out.println("Alimento não encontrado.");
            }
        } catch (RuntimeException e) {
            System.err.println("Erro ao buscar alimento: " + e.getMessage());
        }
    }

    public void listarAlimentos() {
        try {
            List<Alimento> alimentos = alimentoService.listarAlimentos();
            alimentos.forEach(System.out::println);
        } catch (RuntimeException e) {
            System.err.println("Erro ao listar alimentos: " + e.getMessage());
        }
    }

    public void atualizarAlimento(Alimento alimento) {
        try {
            alimentoService.atualizarAlimento(alimento);
            System.out.println("Alimento atualizado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao atualizar alimento: " + e.getMessage());
        }
    }

    public void deletarAlimento(int id) {
        try {
            alimentoService.deletarAlimento(id);
            System.out.println("Alimento deletado com sucesso!");
        } catch (RuntimeException e) {
            System.err.println("Erro ao deletar alimento: " + e.getMessage());
        }
    }
}
