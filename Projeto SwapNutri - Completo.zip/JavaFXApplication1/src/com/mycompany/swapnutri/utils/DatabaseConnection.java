package com.mycompany.swapnutri.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection implements Conexao {

    private static final String URL = "jdbc:mysql://localhost:3306/swap_nutri_db"; // Corrigido o nome do banco
    private static final String USUARIO = "root";
    private static final String SENHA = "123456";
    private static Connection conectar;

    @Override
    public Connection obterConexao() throws SQLException {
        if (conectar == null || conectar.isClosed()) {
            conectar = DriverManager.getConnection(URL, USUARIO, SENHA);
        }
        return conectar;
    }

    // Método estático para obter conexão
    public static Connection getConnection() {
        try {
            if (conectar == null || conectar.isClosed()) {
                conectar = DriverManager.getConnection(URL, USUARIO, SENHA);
            }
            return conectar;
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao conectar ao banco de dados: " + e.getMessage(), e);
        }
    }
}
