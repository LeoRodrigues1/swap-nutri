package com.mycompany.swapnutri.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import com.mycompany.swapnutri.controllers.UsuarioController;
import com.mycompany.swapnutri.models.Usuario;
import com.mycompany.swapnutri.models.Sexo;
import com.mycompany.swapnutri.utils.DatabaseConnection;
import java.sql.Connection;

public class CadastroScreen {
    private UsuarioController usuarioController;

    public CadastroScreen() {
        Connection connection = DatabaseConnection.getConnection();
        this.usuarioController = new UsuarioController(connection);
    }

    public void start(Stage primaryStage) {
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(20));
        vbox.setAlignment(Pos.CENTER);

        
        Label errorLabel = new Label();
        errorLabel.getStyleClass().add("error-label");
        errorLabel.setVisible(false);

       
        TextField nomeField = new TextField();
        nomeField.setPromptText("Nome Completo *");

        TextField emailField = new TextField();
        emailField.setPromptText("Email *");

        PasswordField senhaField = new PasswordField();
        senhaField.setPromptText("Senha *");

        TextField pesoField = new TextField();
        pesoField.setPromptText("Peso (kg) *");

        TextField alturaField = new TextField();
        alturaField.setPromptText("Altura (m) *");

        TextField idadeField = new TextField();
        idadeField.setPromptText("Idade *");

        ComboBox<Sexo> sexoComboBox = new ComboBox<>();
        sexoComboBox.getItems().addAll(Sexo.values());
        sexoComboBox.setPromptText("Sexo *");

        Button cadastrarButton = new Button("Cadastrar");
        cadastrarButton.setOnAction(e -> {
            errorLabel.setVisible(false);

            try {
                String nome = nomeField.getText().trim();
                String email = emailField.getText().trim();
                String senha = senhaField.getText().trim();
                String pesoStr = pesoField.getText().trim();
                String alturaStr = alturaField.getText().trim();
                String idadeStr = idadeField.getText().trim();
                Sexo sexo = sexoComboBox.getValue();

                
                if (nome.isEmpty() || email.isEmpty() || senha.isEmpty() || 
                    pesoStr.isEmpty() || alturaStr.isEmpty() || idadeStr.isEmpty() || sexo == null) {
                    errorLabel.setText("Todos os campos marcados com * são obrigatórios!");
                    errorLabel.setVisible(true);
                    return;
                }

               
                float peso = Float.parseFloat(pesoStr);
                float altura = Float.parseFloat(alturaStr);
                int idade = Integer.parseInt(idadeStr);

                
                Usuario novoUsuario = new Usuario(0, nome, email, senha, peso, altura, idade, sexo);
                usuarioController.adicionarUsuario(novoUsuario);
                AppNav.navigateTo("login");
                primaryStage.close();

            } catch (NumberFormatException ex) {
                errorLabel.setText("Peso, altura e idade devem ser números válidos!");
                errorLabel.setVisible(true);
            }
        });

        Button voltarButton = new Button("Voltar");
        voltarButton.setOnAction(e -> {
            AppNav.navigateTo("login");
            primaryStage.close();
        });

        vbox.getChildren().addAll(
            nomeField, emailField, senhaField, 
            pesoField, alturaField, idadeField, 
            sexoComboBox, errorLabel, cadastrarButton, voltarButton
        );

        Scene scene = new Scene(vbox, 300, 600);
        scene.getStylesheets().add(getClass().getResource("/com/mycompany/swapnutri/view/styles.css").toExternalForm());
        primaryStage.setTitle("Cadastro de Usuário");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}