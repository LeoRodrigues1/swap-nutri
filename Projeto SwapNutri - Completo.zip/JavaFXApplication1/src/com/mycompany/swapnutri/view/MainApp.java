package com.mycompany.swapnutri.view;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import com.mycompany.swapnutri.controllers.UsuarioController;
import com.mycompany.swapnutri.controllers.CalculadoraController;
import com.mycompany.swapnutri.utils.DatabaseConnection;
import java.sql.Connection;

public class MainApp extends Application {
    private Stage primaryStage;
    private UsuarioController usuarioController;
    private Connection connection;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setMinWidth(400);
        primaryStage.setMinHeight(400);

        // Configuração de navegação
        AppNav.setNavigationListener(destination -> {
            switch (destination) {
                case "login":
                    showLoginScreen();
                    break;
                case "cadastro":
                    showCadastroScreen();
                    break;
                case "main":
                    showMainScreen();
                    break;
                case "refeicoesDiarias":
                    showRefeicoesDiariasScreen();
                    break;
                case "calculadora":
                    showCalculadoraScreen();
                    break;
                default:
                    System.out.println("Destino não reconhecido: " + destination);
            }
        });

        connection = DatabaseConnection.getConnection();
        this.usuarioController = new UsuarioController(connection);

        showLoginScreen();
    }

    private void showLoginScreen() {
        VBox container = new VBox(15);
        container.getStyleClass().add("container");
        container.setAlignment(Pos.CENTER);

        Label title = new Label("Login");
        title.getStyleClass().add("title");

        TextField emailField = new TextField();
        emailField.setPromptText("E-mail");

        PasswordField senhaField = new PasswordField();
        senhaField.setPromptText("Senha");

        Label errorLabel = new Label();
        errorLabel.getStyleClass().add("error-label");
        errorLabel.setVisible(false);

        Button loginButton = new Button("Entrar");
        loginButton.getStyleClass().add("button");
        loginButton.setOnAction(e -> {
            String email = emailField.getText().trim();
            String senha = senhaField.getText().trim();

            if (email.isEmpty() || senha.isEmpty()) {
                errorLabel.setText("Preencha todos os campos!");
                errorLabel.setVisible(true);
                return;
            }

            if (usuarioController.verificarCredenciais(email, senha)) {
                AppNav.navigateTo("main");
            } else {
                errorLabel.setText("Credenciais inválidas!");
                errorLabel.setVisible(true);
            }
        });

        Button cadastroButton = new Button("Criar Nova Conta");
        cadastroButton.setId("registerButton");
        cadastroButton.setOnAction(e -> AppNav.navigateTo("cadastro"));

        container.getChildren().addAll(
            title,
            emailField,
            senhaField,
            errorLabel,
            loginButton,
            cadastroButton
        );

        Scene scene = new Scene(container, 400, 450);
        scene.getStylesheets().add(getClass().getResource("/com/mycompany/swapnutri/view/styles.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.setTitle("SwapNutri - Login");
        primaryStage.show();
    }

    private void showCadastroScreen() {
        new CadastroScreen().start(primaryStage);
    }

    private void showMainScreen() {
        VBox container = new VBox(20);
        container.getStyleClass().add("container");
        container.setAlignment(Pos.CENTER);

        Label title = new Label("Bem-vindo ao SwapNutri");
        title.getStyleClass().add("title");

        Button btnPlano = new Button("Meu Plano Nutricional");
        Button btnRefeicoes = new Button("Refeições Diárias");
        Button btnCalculadora = new Button("Calculadora Nutricional"); // NOVO BOTÃO
        Button btnSair = new Button("Sair");

        btnPlano.getStyleClass().add("button");
        btnRefeicoes.getStyleClass().add("button");
        btnCalculadora.getStyleClass().add("button");
        btnSair.getStyleClass().add("button");

        btnRefeicoes.setOnAction(e -> AppNav.navigateTo("refeicoesDiarias"));
        btnCalculadora.setOnAction(e -> AppNav.navigateTo("calculadora")); // ABRE A CALCULADORA
        btnSair.setOnAction(e -> AppNav.navigateTo("login"));

        container.getChildren().addAll(
            title,
            btnPlano,
            btnRefeicoes,
            btnCalculadora, // ADICIONADO NO MENU PRINCIPAL
            btnSair
        );

        Scene scene = new Scene(container, 500, 500);
        scene.getStylesheets().add(getClass().getResource("/com/mycompany/swapnutri/view/styles.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.setTitle("SwapNutri - Painel Principal");
        primaryStage.show();
    }

    private void showRefeicoesDiariasScreen() {
        new RefeicoesDiariasScreen().start(primaryStage);
    }

    private void showCalculadoraScreen() {
        CalculadoraController calculadoraController = new CalculadoraController(connection);
        CalculadoraScreen calculadoraScreen = new CalculadoraScreen(calculadoraController);

        Scene scene = new Scene(calculadoraScreen.getRoot(), 500, 500);
        scene.getStylesheets().add(getClass().getResource("/com/mycompany/swapnutri/view/styles.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.setTitle("SwapNutri - Calculadora Nutricional");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
