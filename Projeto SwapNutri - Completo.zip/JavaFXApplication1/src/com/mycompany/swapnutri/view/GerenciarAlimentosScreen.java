package com.mycompany.swapnutri.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import com.mycompany.swapnutri.controllers.AlimentoController;
import com.mycompany.swapnutri.models.Alimento;
import com.mycompany.swapnutri.utils.DatabaseConnection;

import java.sql.Connection;

public class GerenciarAlimentosScreen {
    private AlimentoController alimentoController;

    public GerenciarAlimentosScreen() {
        
        Connection connection = DatabaseConnection.getConnection();
        this.alimentoController = new AlimentoController(connection);
    }

    public void start(Stage primaryStage) {
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(20));
        vbox.setAlignment(Pos.CENTER);
        vbox.getStyleClass().add("container");

        TextField nomeField = new TextField();
        nomeField.setPromptText("Nome do Alimento");
        nomeField.getStyleClass().add("text-field");

        TextField categoriaField = new TextField();
        categoriaField.setPromptText("Categoria");
        categoriaField.getStyleClass().add("text-field");

        TextField caloriasField = new TextField();
        caloriasField.setPromptText("Calorias");
        caloriasField.getStyleClass().add("text-field");

        TextField carboidratosField = new TextField();
        carboidratosField.setPromptText("Carboidratos");
        carboidratosField.getStyleClass().add("text-field");

        TextField proteinasField = new TextField();
        proteinasField.setPromptText("Proteínas");
        proteinasField.getStyleClass().add("text-field");

        TextField gordurasTotaisField = new TextField();
        gordurasTotaisField.setPromptText("Gorduras Totais");
        gordurasTotaisField.getStyleClass().add("text-field");

        TextField gordurasSaturadasField = new TextField();
        gordurasSaturadasField.setPromptText("Gorduras Saturadas");
        gordurasSaturadasField.getStyleClass().add("text-field");

        TextField fibrasField = new TextField();
        fibrasField.setPromptText("Fibras");
        fibrasField.getStyleClass().add("text-field");

        TextField pesoField = new TextField();
        pesoField.setPromptText("Peso (g)");
        pesoField.getStyleClass().add("text-field");

        TextField volumeField = new TextField();
        volumeField.setPromptText("Volume (ml)");
        volumeField.getStyleClass().add("text-field");

        Button salvarButton = new Button("Salvar");
        salvarButton.getStyleClass().add("button"); 
        salvarButton.setOnAction(e -> {
            try {
                String nome = nomeField.getText();
                String categoria = categoriaField.getText();
                double calorias = Double.parseDouble(caloriasField.getText());
                double carboidratos = Double.parseDouble(carboidratosField.getText());
                double proteinas = Double.parseDouble(proteinasField.getText());
                double gordurasTotais = Double.parseDouble(gordurasTotaisField.getText());
                double gordurasSaturadas = Double.parseDouble(gordurasSaturadasField.getText());
                double fibras = Double.parseDouble(fibrasField.getText());
                double peso = Double.parseDouble(pesoField.getText());
                double volume = Double.parseDouble(volumeField.getText());

                Alimento novoAlimento = new Alimento(0, nome, categoria, calorias, carboidratos, proteinas, gordurasTotais, gordurasSaturadas, fibras, peso, volume);
                alimentoController.adicionarAlimento(novoAlimento);
                System.out.println("Alimento cadastrado com sucesso!");
            } catch (NumberFormatException ex) {
                System.out.println("Erro: Certifique-se de preencher os campos numéricos corretamente.");
            }
        });

        vbox.getChildren().addAll(
            nomeField, categoriaField, caloriasField, carboidratosField, 
            proteinasField, gordurasTotaisField, gordurasSaturadasField, fibrasField, 
            pesoField, volumeField, salvarButton
        );

        
        Scene scene = new Scene(vbox, 400, 600);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm()); // Adiciona a folha de estilos

        primaryStage.setTitle("Gerenciar Alimentos");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
