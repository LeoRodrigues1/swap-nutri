package com.mycompany.swapnutri.view;

import com.mycompany.swapnutri.dao.RefeicoesDiariasDAO;
import com.mycompany.swapnutri.models.RefeicoesDiarias;
import com.mycompany.swapnutri.utils.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javafx.scene.layout.VBox;

public class RefeicoesDiariasScreen {

    private final RefeicoesDiariasDAO refeicoesDAO;
    private TableView<RefeicoesDiarias> tabelaRefeicoes;

    public RefeicoesDiariasScreen() {
        Connection connection = DatabaseConnection.getConnection();
        this.refeicoesDAO = new RefeicoesDiariasDAO(connection);
    }

    public void start(Stage primaryStage) {
        VBox container = new VBox(15);
        container.setPadding(new Insets(20));
        container.setAlignment(Pos.CENTER);
        container.getStyleClass().add("container");

        Label titulo = new Label("Refeições Diárias");
        titulo.getStyleClass().add("title");

        configurarTabela();
        carregarDados();

        Button btnVoltar = new Button("Voltar");
        btnVoltar.getStyleClass().add("button");
        btnVoltar.setOnAction(e -> primaryStage.close());

        container.getChildren().addAll(titulo, tabelaRefeicoes, btnVoltar);

        Scene scene = new Scene(container, 800, 600);
        scene.getStylesheets().add(getClass().getResource("/com/mycompany/swapnutri/view/styles.css").toExternalForm());
        primaryStage.setTitle("Gerenciamento de Refeições Diárias");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void configurarTabela() {
        tabelaRefeicoes = new TableView<>();
        tabelaRefeicoes.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<RefeicoesDiarias, String> colRefeicao = new TableColumn<>("Refeição");
        colRefeicao.setCellValueFactory(new PropertyValueFactory<>("refeicao"));

        TableColumn<RefeicoesDiarias, String> colHoraInicio = new TableColumn<>("Hora Início");
        colHoraInicio.setCellValueFactory(new PropertyValueFactory<>("horaInicio"));

        TableColumn<RefeicoesDiarias, String> colHoraFim = new TableColumn<>("Hora Fim");
        colHoraFim.setCellValueFactory(new PropertyValueFactory<>("horaFim"));

        TableColumn<RefeicoesDiarias, Integer> colUsuario = new TableColumn<>("ID Usuário");
        colUsuario.setCellValueFactory(new PropertyValueFactory<>("usuarioId"));

        tabelaRefeicoes.getColumns().addAll(colRefeicao, colHoraInicio, colHoraFim, colUsuario);
    }

    private void carregarDados() {
        try {
            List<RefeicoesDiarias> refeicoes = refeicoesDAO.listarRefeicoesDiarias();
            tabelaRefeicoes.setItems(FXCollections.observableArrayList(refeicoes));
        } catch (SQLException e) {
            mostrarErro("Erro ao carregar refeições: " + e.getMessage());
        }
    }

    private void mostrarErro(String mensagem) {
        System.err.println(mensagem);
    }
}
