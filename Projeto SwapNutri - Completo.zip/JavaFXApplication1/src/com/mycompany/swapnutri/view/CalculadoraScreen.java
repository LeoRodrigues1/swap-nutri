package com.mycompany.swapnutri.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import com.mycompany.swapnutri.controllers.CalculadoraController;
import com.mycompany.swapnutri.dao.AlimentoDAO;
import com.mycompany.swapnutri.models.Alimento;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class CalculadoraScreen {
    private VBox root;
    private TextField alimentoOriginalNomeField, quantidadeField, alimentoSubstitutoNomeField;
    private ComboBox<String> nutrienteComboBox;
    private Label resultadoLabel;
    private final CalculadoraController calcController;
    private ObservableList<String> sugestoes; 
    private AlimentoDAO alimentoDAO;
    private Connection connection;

    // Criamos um único ContextMenu para ser reutilizado
    private final ContextMenu menuSugestoes = new ContextMenu();

    public CalculadoraScreen(CalculadoraController calcController) {
        this.calcController = calcController;
        this.alimentoDAO = new AlimentoDAO(connection); 
        initializeUI();
    }

    private void initializeUI() {
        root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Label titulo = new Label("Calculadora Nutricional");
        titulo.getStyleClass().add("title");

        // Campo para o nome do alimento original
        alimentoOriginalNomeField = new TextField();
        alimentoOriginalNomeField.setPromptText("Nome do Alimento Original");
        
        // Adicionando o listener para autocompletar
        alimentoOriginalNomeField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.isEmpty()) {
                buscarSugestoes(newValue, alimentoOriginalNomeField);
            } else {
                menuSugestoes.hide();
            }
        });

        
        quantidadeField = new TextField();
        quantidadeField.setPromptText("Quantidade (g)");

        
        alimentoSubstitutoNomeField = new TextField();
        alimentoSubstitutoNomeField.setPromptText("Nome do Alimento Substituto");

        
        alimentoSubstitutoNomeField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null && !newValue.isEmpty()) {
                buscarSugestoes(newValue, alimentoSubstitutoNomeField);
            } else {
                menuSugestoes.hide();
            }
        });

        
        nutrienteComboBox = new ComboBox<>();
        nutrienteComboBox.getItems().addAll("Calorias", "Carboidratos", "Proteínas", "Gorduras");
        nutrienteComboBox.setValue("Calorias");

       
        Button calcularButton = new Button("Calcular Equivalência");
        calcularButton.setOnAction(e -> calcularEquivalencia());

        
        Button calcularNutrienteButton = new Button("Calcular por Nutriente");
        calcularNutrienteButton.setOnAction(e -> calcularPorNutriente());

resultadoLabel = new Label();
resultadoLabel.getStyleClass().add("result-label");
resultadoLabel.setWrapText(true);
resultadoLabel.setMaxWidth(600); 
resultadoLabel.setAlignment(Pos.CENTER);
resultadoLabel.setStyle("");


        
        root.getChildren().addAll(titulo, alimentoOriginalNomeField, quantidadeField, alimentoSubstitutoNomeField,
                                  calcularButton, nutrienteComboBox, calcularNutrienteButton, resultadoLabel);
    }

    private void buscarSugestoes(String texto, TextField campo) {
        try {
            List<Alimento> alimentosEncontrados = alimentoDAO.buscarAlimentosPorNome(texto);

            
            List<String> nomesUnicos = alimentosEncontrados.stream()
                    .map(Alimento::getNome)
                    .distinct()
                    .collect(Collectors.toList());

            if (!nomesUnicos.isEmpty()) {
                
                menuSugestoes.getItems().clear();

                for (String nomeAlimento : nomesUnicos) {
                    MenuItem item = new MenuItem(nomeAlimento);
                    item.setOnAction(e -> {
                        campo.setText(nomeAlimento);
                        menuSugestoes.hide();
                    });
                    menuSugestoes.getItems().add(item);
                }

                
                menuSugestoes.show(campo, campo.localToScreen(0, campo.getHeight()).getX(), 
                                          campo.localToScreen(0, campo.getHeight()).getY());
            } else {
                menuSugestoes.hide(); 
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void calcularEquivalencia() {
        try {
            String nomeAlimentoOriginal = alimentoOriginalNomeField.getText().trim();
            String nomeAlimentoSubstituto = alimentoSubstitutoNomeField.getText().trim();
            double quantidade = Double.parseDouble(quantidadeField.getText().trim());

            String resultado = calcController.calcularSubstituicao(nomeAlimentoOriginal, quantidade, nomeAlimentoSubstituto);
            resultadoLabel.setText(resultado);

        } catch (NumberFormatException e) {
            resultadoLabel.setText("Erro: Digite uma quantidade numérica.");
        }
    }

    private void calcularPorNutriente() {
        try {
            String nomeAlimentoOriginal = alimentoOriginalNomeField.getText().trim();
            String nomeAlimentoSubstituto = alimentoSubstitutoNomeField.getText().trim();
            double quantidade = Double.parseDouble(quantidadeField.getText().trim());
            String nutriente = nutrienteComboBox.getValue();

            String resultado = calcController.calcularSubstituicaoNutriente(nutriente, nomeAlimentoOriginal, quantidade, nomeAlimentoSubstituto);
            resultadoLabel.setText(resultado);

        } catch (NumberFormatException e) {
            resultadoLabel.setText("Erro: Digite uma quantidade numérica.");
        }
    }

    public VBox getRoot() {
        return root;
    }
}
