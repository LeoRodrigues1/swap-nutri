package com.mycompany.swapnutri.view;

public class AppNav {
    private static AppNavigationListener navigationListener;

    public interface AppNavigationListener {
        void onNavigate(String destination);
    }

    public static void setNavigationListener(AppNavigationListener listener) {
        navigationListener = listener;
    }

    public static void navigateTo(String destination) {
        if (navigationListener != null) {
            navigationListener.onNavigate(destination);
        } else {
            System.out.println("Navegação não configurada para: " + destination);
        }
    }
}