package com.mycompany.swapnutri.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import com.mycompany.swapnutri.controllers.UsuarioController;
import com.mycompany.swapnutri.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.SQLException;

public class LoginScreen {
    private final UsuarioController usuarioController;

    public LoginScreen() {
        
        Connection connection = DatabaseConnection.getConnection();
        this.usuarioController = new UsuarioController(connection);
    }

    public void start(Stage primaryStage) {
        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(20));
        vbox.setAlignment(Pos.CENTER);

        TextField emailField = new TextField();
        emailField.setPromptText("Email");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Senha");

        Button loginButton = new Button("Login");
        loginButton.setOnAction(e -> {
            String email = emailField.getText();
            String senha = passwordField.getText();
            
            if (usuarioController.verificarCredenciais(email, senha)) {
                AppNav.navigateTo("main");
                primaryStage.close();
            } else {
                System.out.println("Email ou senha inválidos.");
            }
        });

        Button registerButton = new Button("Registrar");
        registerButton.setOnAction(e -> {
            AppNav.navigateTo("cadastro");
            primaryStage.close();
        });

        vbox.getChildren().addAll(emailField, passwordField, loginButton, registerButton);

        Scene scene = new Scene(vbox, 300, 200);
        primaryStage.setTitle("Login");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
