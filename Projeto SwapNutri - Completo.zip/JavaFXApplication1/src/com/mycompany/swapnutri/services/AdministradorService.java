package com.mycompany.swapnutri.services;

import com.mycompany.swapnutri.dao.AdministradorDAO;
import com.mycompany.swapnutri.models.Administrador;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class AdministradorService {
    private final AdministradorDAO administradorDAO;

    public AdministradorService(Connection connection) {
        this.administradorDAO = new AdministradorDAO(connection);
    }

    public void adicionarAdministrador(Administrador administrador) {
        try {
            administradorDAO.adicionarAdministrador(administrador);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao adicionar administrador: " + e.getMessage(), e);
        }
    }

    public Administrador buscarAdministradorPorId(int id) {
        try {
            return administradorDAO.buscarAdministradorPorId(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar administrador: " + e.getMessage(), e);
        }
    }

    public List<Administrador> listarAdministradores() {
        try {
            return administradorDAO.listarAdministradores();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar administradores: " + e.getMessage(), e);
        }
    }

    public void atualizarAdministrador(Administrador administrador) {
        try {
            administradorDAO.atualizarAdministrador(administrador);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar administrador: " + e.getMessage(), e);
        }
    }

    public void deletarAdministrador(int id) {
        try {
            administradorDAO.deletarAdministrador(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar administrador: " + e.getMessage(), e);
        }
    }
}
