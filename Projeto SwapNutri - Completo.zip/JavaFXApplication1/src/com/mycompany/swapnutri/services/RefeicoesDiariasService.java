package com.mycompany.swapnutri.services;

import com.mycompany.swapnutri.dao.RefeicoesDiariasDAO;
import com.mycompany.swapnutri.models.RefeicoesDiarias;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class RefeicoesDiariasService {
    private final RefeicoesDiariasDAO refeicoesDiariasDAO;

    public RefeicoesDiariasService(Connection connection) {
        this.refeicoesDiariasDAO = new RefeicoesDiariasDAO(connection);
    }

    public void adicionarRefeicoesDiarias(RefeicoesDiarias refeicoesDiarias) {
        try {
            refeicoesDiariasDAO.adicionarRefeicoesDiarias(refeicoesDiarias);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao adicionar refeição diária: " + e.getMessage(), e);
        }
    }

    public RefeicoesDiarias buscarRefeicoesDiariasPorId(int id) {
        try {
            return refeicoesDiariasDAO.buscarRefeicoesDiariasPorId(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar refeição diária: " + e.getMessage(), e);
        }
    }

    public List<RefeicoesDiarias> listarRefeicoesDiarias() {
        try {
            return refeicoesDiariasDAO.listarRefeicoesDiarias();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar refeições diárias: " + e.getMessage(), e);
        }
    }

    public void atualizarRefeicoesDiarias(RefeicoesDiarias refeicoesDiarias) {
        try {
            refeicoesDiariasDAO.atualizarRefeicoesDiarias(refeicoesDiarias);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar refeição diária: " + e.getMessage(), e);
        }
    }

    public void deletarRefeicoesDiarias(int id) {
        try {
            refeicoesDiariasDAO.deletarRefeicoesDiarias(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar refeição diária: " + e.getMessage(), e);
        }
    }
}
