package com.mycompany.swapnutri.services;

import com.mycompany.swapnutri.dao.AlimentoDAO;
import com.mycompany.swapnutri.models.Alimento;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class AlimentoService {
    private final AlimentoDAO alimentoDAO;

    public AlimentoService(Connection connection) {
        this.alimentoDAO = new AlimentoDAO(connection);
    }

    public void adicionarAlimento(Alimento alimento) {
        try {
            alimentoDAO.adicionarAlimento(alimento);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao adicionar alimento: " + e.getMessage(), e);
        }
    }
public List<Alimento> buscarAlimentosPorNome(String nome) {
    try {
        return alimentoDAO.buscarAlimentosPorNome(nome);
    } catch (SQLException e) {
        throw new RuntimeException("Erro ao buscar alimentos por nome: " + e.getMessage(), e);
    }
}

    public Alimento buscarAlimentoPorId(int id) {
        try {
            return alimentoDAO.buscarAlimentoPorId(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar alimento: " + e.getMessage(), e);
        }
    }

    public List<Alimento> listarAlimentos() {
        try {
            return alimentoDAO.listarAlimentos();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar alimentos: " + e.getMessage(), e);
        }
    }

    public void atualizarAlimento(Alimento alimento) {
        try {
            alimentoDAO.atualizarAlimento(alimento);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar alimento: " + e.getMessage(), e);
        }
    }

    public void deletarAlimento(int id) {
        try {
            alimentoDAO.deletarAlimento(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar alimento: " + e.getMessage(), e);
        }
    }
}
