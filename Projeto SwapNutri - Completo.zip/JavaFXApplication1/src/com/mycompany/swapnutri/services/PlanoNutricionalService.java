package com.mycompany.swapnutri.services;

import com.mycompany.swapnutri.dao.PlanoNutricionalDAO;
import com.mycompany.swapnutri.models.PlanoNutricional;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class PlanoNutricionalService {
    private final PlanoNutricionalDAO planoNutricionalDAO;

    public PlanoNutricionalService(Connection connection) {
        this.planoNutricionalDAO = new PlanoNutricionalDAO(connection);
    }

    public void adicionarPlanoNutricional(PlanoNutricional planoNutricional) {
        try {
            planoNutricionalDAO.adicionarPlanoNutricional(planoNutricional);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao adicionar plano nutricional: " + e.getMessage(), e);
        }
    }

    public PlanoNutricional buscarPlanoNutricionalPorId(int id) {
        try {
            return planoNutricionalDAO.buscarPlanoNutricionalPorId(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar plano nutricional: " + e.getMessage(), e);
        }
    }

    public List<PlanoNutricional> listarPlanosNutricionais() {
        try {
            return planoNutricionalDAO.listarPlanosNutricionais();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar planos nutricionais: " + e.getMessage(), e);
        }
    }

    public void atualizarPlanoNutricional(PlanoNutricional planoNutricional) {
        try {
            planoNutricionalDAO.atualizarPlanoNutricional(planoNutricional);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar plano nutricional: " + e.getMessage(), e);
        }
    }

    public void deletarPlanoNutricional(int id) {
        try {
            planoNutricionalDAO.deletarPlanoNutricional(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar plano nutricional: " + e.getMessage(), e);
        }
    }
}
