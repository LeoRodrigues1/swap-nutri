package com.mycompany.swapnutri.services;

import com.mycompany.swapnutri.dao.ItensRefeicaoDAO;
import com.mycompany.swapnutri.models.ItensRefeicao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class ItensRefeicaoService {
    private final ItensRefeicaoDAO itensRefeicaoDAO;

    public ItensRefeicaoService(Connection connection) {
        this.itensRefeicaoDAO = new ItensRefeicaoDAO(connection);
    }

    public void adicionarItensRefeicao(ItensRefeicao itensRefeicao) {
        try {
            itensRefeicaoDAO.adicionarItensRefeicao(itensRefeicao);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao adicionar item na refeição: " + e.getMessage(), e);
        }
    }

    public ItensRefeicao buscarItensRefeicaoPorId(int id) {
        try {
            return itensRefeicaoDAO.buscarItensRefeicaoPorId(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar item na refeição: " + e.getMessage(), e);
        }
    }

    public List<ItensRefeicao> listarItensRefeicao() {
        try {
            return itensRefeicaoDAO.listarItensRefeicao();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar itens na refeição: " + e.getMessage(), e);
        }
    }

    public void atualizarItensRefeicao(ItensRefeicao itensRefeicao) {
        try {
            itensRefeicaoDAO.atualizarItensRefeicao(itensRefeicao);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar item na refeição: " + e.getMessage(), e);
        }
    }

    public void deletarItensRefeicao(int id) {
        try {
            itensRefeicaoDAO.deletarItensRefeicao(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar item na refeição: " + e.getMessage(), e);
        }
    }
}
