package com.mycompany.swapnutri.services;

import com.mycompany.swapnutri.dao.UsuarioDAO;
import com.mycompany.swapnutri.models.Usuario;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class UsuarioService {
    private final UsuarioDAO usuarioDAO;

    public UsuarioService(Connection connection) {
        this.usuarioDAO = new UsuarioDAO(connection);
    }

    public void adicionarUsuario(Usuario usuario) {
        try {
            usuarioDAO.adicionarUsuario(usuario);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao adicionar usuário: " + e.getMessage(), e);
        }
    }

    public Usuario buscarUsuarioPorId(int id) {
        try {
            return usuarioDAO.buscarUsuarioPorId(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar usuário: " + e.getMessage(), e);
        }
    }

    public List<Usuario> listarUsuarios() {
        try {
            return usuarioDAO.listarUsuarios();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar usuários: " + e.getMessage(), e);
        }
    }

    public void atualizarUsuario(Usuario usuario) {
        try {
            usuarioDAO.atualizarUsuario(usuario);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar usuário: " + e.getMessage(), e);
        }
    }

    public void deletarUsuario(int id) {
        try {
            usuarioDAO.deletarUsuario(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar usuário: " + e.getMessage(), e);
        }
    }
}
