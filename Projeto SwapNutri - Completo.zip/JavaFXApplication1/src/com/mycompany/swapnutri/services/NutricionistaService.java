package com.mycompany.swapnutri.services;

import com.mycompany.swapnutri.dao.NutricionistaDAO;
import com.mycompany.swapnutri.models.Nutricionista;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class NutricionistaService {
    private final NutricionistaDAO nutricionistaDAO;

    public NutricionistaService(Connection connection) {
        this.nutricionistaDAO = new NutricionistaDAO(connection);
    }

    public void adicionarNutricionista(Nutricionista nutricionista) {
        try {
            nutricionistaDAO.adicionarNutricionista(nutricionista);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao adicionar nutricionista: " + e.getMessage(), e);
        }
    }

    public Nutricionista buscarNutricionistaPorId(int id) {
        try {
            return nutricionistaDAO.buscarNutricionistaPorId(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar nutricionista: " + e.getMessage(), e);
        }
    }

    public List<Nutricionista> listarNutricionistas() {
        try {
            return nutricionistaDAO.listarNutricionistas();
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao listar nutricionistas: " + e.getMessage(), e);
        }
    }

    public void atualizarNutricionista(Nutricionista nutricionista) {
        try {
            nutricionistaDAO.atualizarNutricionista(nutricionista);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao atualizar nutricionista: " + e.getMessage(), e);
        }
    }

    public void deletarNutricionista(int id) {
        try {
            nutricionistaDAO.deletarNutricionista(id);
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao deletar nutricionista: " + e.getMessage(), e);
        }
    }
}
