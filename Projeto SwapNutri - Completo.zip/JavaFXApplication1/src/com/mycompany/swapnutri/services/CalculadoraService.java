package com.mycompany.swapnutri.services;

import com.mycompany.swapnutri.models.Alimento;
import java.sql.Connection;

public class CalculadoraService {

    public CalculadoraService(Connection connection) {
    }
    public double calcularEquivalencia(Alimento alimentoOriginal, double quantidade, Alimento alimentoSubstituto) {
        if (alimentoSubstituto.getCalorias() <= 0) {
            throw new ArithmeticException("Alimento substituto possui calorias inválidas para cálculo.");
        }

        double proporcaoCalorias = alimentoOriginal.getCalorias() / alimentoSubstituto.getCalorias();
        return quantidade * proporcaoCalorias;
    }

    public double calcularPorNutriente(String nutriente, Alimento alimentoOriginal, double quantidade, Alimento alimentoSubstituto) {
        double valorOriginal = 0;
        double valorSubstituto = 0;

        switch (nutriente.toLowerCase()) {
            case "carboidratos":
                valorOriginal = alimentoOriginal.getCarboidratos();
                valorSubstituto = alimentoSubstituto.getCarboidratos();
                break;
            case "proteínas":
                valorOriginal = alimentoOriginal.getProteinas();
                valorSubstituto = alimentoSubstituto.getProteinas();
                break;
            case "gorduras":
                valorOriginal = alimentoOriginal.getGorduras_totais();
                valorSubstituto = alimentoSubstituto.getGorduras_totais();
                break;
            default: // Calorias
                valorOriginal = alimentoOriginal.getCalorias();
                valorSubstituto = alimentoSubstituto.getCalorias();
        }

        if (valorSubstituto <= 0) {
            throw new ArithmeticException("Valor nutricional inválido para cálculo.");
        }

        return (valorOriginal / valorSubstituto) * quantidade;
    }
}
